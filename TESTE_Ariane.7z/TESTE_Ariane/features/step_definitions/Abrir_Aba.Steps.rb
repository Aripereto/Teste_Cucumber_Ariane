Dado("que eu esteja na tela do site") do
 visit('https://the-internet.herokuapp.com/windows')
end

Dado("clico no link click here") do
  click_link('Click Here')
end

Então("uma nova aba e aberta") do
page.has_content?("New Window")
end