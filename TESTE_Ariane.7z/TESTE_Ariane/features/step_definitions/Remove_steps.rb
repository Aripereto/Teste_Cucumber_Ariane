Dado("que eu esteja na tela do site") do
  visit('https://the-internet.herokuapp.com/dynamic_controls')
end

Dado("clico no botão REMOVE") do
  page.find(:id, 'btn').click
end

Então("o checkbox e removido da tela") do
  page.has_content?("It's gone")
  sleep 1
end

Dado("clico no botão ADD") do
  page.find(:id, 'btn').click
end

Então("o checkbox e apresentado na tela") do
  page.has_content?("A checkbox")
end